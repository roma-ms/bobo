from setuptools import setup

setup(
    name='ddap-awsume-plugin',
    version='0.0.0',
    entry_points={
        'awsume': [
            'ddap = ddap'
        ]
    },
    author='Callum MacGregor',
    author_email='callum.macgregor@contino.io',
    py_modules=['ddap'],
)
