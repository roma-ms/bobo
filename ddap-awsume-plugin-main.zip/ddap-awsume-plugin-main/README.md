# ddap-awsume-plugin

This repo contains an [awsume](https://awsu.me/) plugin to allow cli login via Keycloak SAML to the DDAP AWS accounts.

## Requirements

The following packages are required to use this repo:

* AWS CLI v2
* [AWS CLI Session Manager Plugin](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager-working-with-install-plugin.html)
* [AWSume](https://awsu.me)
* Python 3.8+
* [`pip`]()


## Installation
To use the tool you will need to:
1. install `awsume` and the `ddap-awsume-plugin`
2. add a `saml` section to your `~/.awsume/config.yaml` file
3. point the `sslverification` variable in your `~/.awsume/config.yaml` to the DDAP CA chain file
4. add an alias

### Install the plugin

You can install the plugin with `pip` directly from this repository or if you have a copy of the repository locally

```bash
python -m pip3 install awsume requests xmltodict beautifulsoup4 

# If Installing from GitLab directly
python -m pip3 install git+https://gitlab.ddap-ops.ice.mod.gov.uk/ddap-public/ddap-awsume-plugin.git

# If Installing from within a local copy of the repo
python -m pip3 install -e .
```
*N.B. If you are one of those people who needs mulitple Python versions on their machine, you can create a virtualenv and then install the plugin in the virtualenv, but you will need that virtualenv to be active when you run the tool.*

### Configuration file setup
To be able to interact with AWS you will need to assume one of the AWS IAM roles that are available to you. When you assume the role you will be given credentials, these will be provided by the tool and there is no need to make any changes to your `~/.aws/config` or `~/.aws/credentials`.

To access the various accounts, the profile configuration must be added to the `~/.awsume/config.yaml` file as below. In the case you are using Windows CMD/Powershell the `.awsume` directory will typically live in your user home directory e.g `C:\Users\yourusername\.awsume`

If you do not have an awsume config file present please just run the `awsume` command from your terminal which will create a default configuration file. 

`.awsume/config.yaml`
```yaml
saml:
  sslverification: True
  idpentryurl: 'https://keycloak.ddap-ops.ice.mod.gov.uk/auth/realms/ddap/protocol/saml/clients/amazon-aws'
  username: 'YOUR_KEYCLOAK_USERNAME'
```
*N.B. The `username` configuration is optional. If it is not set then the plugin will ask you to enter it. This is useful for multi-user installations (e.g. in a Kasm image).*

***
##### *** For DDAP Platform developers only ***

Since developers of DDAP will access the platform via the VPN you will need to set the `sslverification` option differently as traffic is routed via our VPN.
Please set your `.awsume/config.yaml` with the following options:
  ```yaml
  saml:
    sslverification: '/path/to/gitlab-ddap-ops-ice-mod-gov-uk-chain.pem'
    idpentryurl: 'https://keycloak.ddap-ops.ice.mod.gov.uk/auth/realms/ddap/protocol/saml/clients/amazon-aws'
    username: 'YOUR_KEYCLOAK_USERNAME'
  ```

  ###### DDAP CA File
You will need the DDAP  CA PEM file to allow `awsume` to trust Keycloak's SSL certificate. Place this in a location in your home folder and point the point the `sslverification` variable in your `~/.awsume/config.yaml` to it.
***



### Running Awsume

#### Windows Users
If you are using PowerShell/CMD in Windows the following command can be used to call Awsume `awsume --with-saml --role-duration 3600` 

If you have Git Bash in Windows or are using a Linux based environment, the below expression above can be added to `~/.bashrc`in order for it to be picked up on PATH.

`~/.bashrc`
```bash
ddap() {
  DUR=`expr $((${1:-1} * 3600))`
  awsume --with-saml --role-duration ${DUR}
}
```

#### Linux-based Users

The following function can be added to your shell's rc file to simplify use. Make sure you have the `awsume` python package installed and available in your PATH for this to work.

`~/.zshrc` or `~/.bashrc`
```bash
ddap() {
  DUR=`expr $((${1:-1} * 3600))`
  awsume --with-saml --role-duration ${DUR}
}
```

### Adding an alias that persists credentials to disk
This function builds on the above and will automatically generate you and ~/.aws/credentials file which means credentials are persisted to disk and will then be available to other applications
```bash
ddap() {
  DUR=`expr $((${1:-1} * 3600))`
  awsume --with-saml --role-duration ${DUR}

  mkdir -p $HOME/.aws
 
  # Set the settings folder location.
  USER_AWS_SETTINGS_FOLDER=$HOME/.aws

  # Create a file to store the temporary credentials on behalf of the user.
  USER_AWS_CREDENTIALS_FILE=${USER_AWS_SETTINGS_FOLDER}/credentials

  # First check if the file exists - if it does, remove it as we will recreate it
  [ -f "$USER_AWS_CREDENTIALS_FILE" ] && rm $USER_AWS_CREDENTIALS_FILE
  touch $USER_AWS_CREDENTIALS_FILE

  # Write these to file
  echo '[default]' > $USER_AWS_CREDENTIALS_FILE
  echo "aws_access_key_id=${AWS_ACCESS_KEY_ID}" >> $USER_AWS_CREDENTIALS_FILE
  echo "aws_secret_access_key=${AWS_SECRET_ACCESS_KEY}" >> $USER_AWS_CREDENTIALS_FILE
  echo "aws_session_token=${AWS_SESSION_TOKEN}" >> $USER_AWS_CREDENTIALS_FILE

  # Need to remove the environment credentials to stop applications using these over cred file
  unset -v AWS_ACCESS_KEY_ID
  unset -v AWS_SECRET_ACCESS_KEY
  unset -v AWS_SESSION_TOKEN

  chmod a+r ${USER_AWS_CREDENTIALS_FILE}

  # Export this value as it is needed for other applications
  export AWS_SHARED_CREDENTIALS_FILE=$USER_AWS_CREDENTIALS_FILE
}
```




## Usage 
Once the function has been added, simply run `ddap` from the shell to get prompted for your Keycloak SSO credentials and OTP token. Once you have logged in you will be presented with a menu of roles that are available to you. This session will be 1 hour long. If you want a longer session then run `ddap <N>` where `N` is the number of hours you want your session to be. If you choose a session length longer than the role you assume allows, you will get an error. `ops`, `dev`, `test` roles have an 8 hour limit. `preprod` and `prod` have a 1 hour limit.

*N.B. To use the AWS IAM credentials, you will need to be in the same shell where you ran the `ddap` function, as the credentials are stored in ENV variables and are not saved anywhere.*

## Troubleshooting
Some common errors:
* `Invalid URL`...
  * Check you have the correct Keycloak URL in your awsume `config.yaml`
* `MaxRetryError`
  * Check you are connected to one of the DDAP VPN's
* `Could not find a suitable TLS CA certificate bundle`
  * Check you have the correct CA pem file and you are pointing to it in your awsume `config.yaml`
* `Warning: the awsume shell script is not being sourced, please use awsume-configure to install the alias`
  * Run `awsume-configure` to set up the alias that will make sure this is sourced
* `The requested DurationSeconds exceeds the MaxSessionDuration set for this role`
  * You chose a session duration that is too long. See [Usage](#markdown-header-usage) above

