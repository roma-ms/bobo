import argparse
import sys
import requests
import getpass
import logging
import xml.etree.ElementTree as ET
import re
from bs4 import BeautifulSoup
from os.path import expanduser
from datetime import datetime

from awsume.awsumepy import hookimpl, safe_print
 
@hookimpl
def get_credentials_with_saml(config: dict, arguments: argparse.Namespace):

    sslverification = config.get('saml').get('sslverification')
    idpentryurl = config.get('saml').get('idpentryurl')
    username =  config.get('saml').get('username')
    if sslverification == None or idpentryurl == None:
        safe_print(f'Could not find all the necessary config.')
        safe_print(f'sslverification: {sslverification}')
        safe_print(f'idpentry: {idpentryurl}')
        safe_print('\nHandy hint:')
        safe_print(f'Have you set up the awsume config.yaml file?')
        sys.exit(0)
    
     # Get the federated credentials from the user
    if username:
        safe_print(f'Using username: {username}')
    else:
        safe_print('Username:', end=' ')
        username = input()

    password = getpass.getpass()
    safe_print('')

    # Initiate session handler
    session = requests.Session()

    # Programmatically get the SAML assertion
    # Opens the initial IdP url and follows all of the HTTP302 redirects, and
    # gets the resulting login page
    try:
        formresponse = session.get(idpentryurl, verify=sslverification)
    except BaseException as err:
        safe_print(f'Could not connect to {idpentryurl} \nUnexpected {err=}, {type(err)=}\n\nHandy hint:\nIs your idpentryurl variable set in the awsume config.yaml file?\n')
        sys.exit(0)

    # Capture the idpauthformsubmiturl, which is the final url after all the 302s
    idpauthformsubmiturl = formresponse.url

    # Parse the response and extract all the necessary values
    # in order to build a dictionary of all of the form values the IdP expects
    formsoup = BeautifulSoup(formresponse.text, features='html.parser')
    auth_payload = {}

    for inputtag in formsoup.find_all(re.compile('(INPUT|input)')):
        name = inputtag.get('name','')
        value = inputtag.get('value','')
        if "user" in name.lower():
            auth_payload[name] = username
        elif "pass" in name.lower():
            auth_payload[name] = password

    for inputtag in formsoup.find_all(re.compile('(FORM|form)')):
        action = inputtag.get('action')
        if action:
            idpauthformsubmiturl = action

    # Performs the submission of the IdP login form with the above post data
    try:
        response = session.post(
            idpauthformsubmiturl, data=auth_payload, verify=sslverification)
    except BaseException as err:
        safe_print(f'Could not connect to {idpauthformsubmiturl} \nUnexpected {err=}, {type(err)=}')
        sys.exit(0)

    # Overwrite and delete the credential variables, just for safety
    username = '##############################################'
    password = '##############################################'
    del username
    del password

    otpsoup = BeautifulSoup(response.text, features='html.parser')

    # Get the OTP from the user
    safe_print("OTP:", end=' ')
    otp = input()
    safe_print('')
    idpotpformsubmiturl = ''
    for inputtag in otpsoup.find_all(re.compile('(FORM|form)')):
        otp_action = inputtag.get('action')
        if otp_action:
            idpotpformsubmiturl = otp_action

    otp_payload = {}

    for inputtag in otpsoup.find_all(re.compile('(INPUT|input)')):
        name = inputtag.get('name','')
        value = inputtag.get('value','')
        if "otp" in name.lower():
            otp_payload[name] = otp


    # Performs the submission of the IdP login form with the above post data
    try:
        response = session.post(
            idpotpformsubmiturl, data=otp_payload, verify=sslverification)
    except BaseException as err:
        safe_print(f'Could not connect to {idpauthformsubmiturl} \nUnexpected {err=}, {type(err)=}')
        sys.exit(0)
        
    # Overwrite and delete the otp variable, just for safety
    otp = '##############################################'
    del otp

    # Decode the response and extract the SAML assertion
    soup = BeautifulSoup(response.text, features='html.parser')
    assertion = ''

    # Look for the SAMLResponse attribute of the input tag (determined by
    # analyzing the debug print lines above)
    for inputtag in soup.find_all('input'):
        if(inputtag.get('name') == 'SAMLResponse'):
            assertion = inputtag.get('value')

    if (assertion == ''):
        safe_print('No SAML assertion found. Likely due to incorrection login credentials.\nPlease try again or contact your administrator.')
        sys.exit(0)

    return assertion

